<?php
$id_telegram = "8273540244";
$id_botTele  = "8400265496:AAH_CkqR7zsvva73-zM4uZpEGvFhToAlgso";
?>
